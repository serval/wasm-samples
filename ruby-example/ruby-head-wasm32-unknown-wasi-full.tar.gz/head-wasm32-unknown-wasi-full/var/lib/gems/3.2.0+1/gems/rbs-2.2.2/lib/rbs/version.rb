module RBS
  VERSION = "2.2.2"
end
